const $ = id => document.getElementById(id);
let currentProject = null;
let deferredInstall = null;
window.addEventListener("beforeinstallprompt", e => {e.preventDefault(); deferredInstall=e; $("installBtn").hidden=false;});
$("installBtn").addEventListener("click", async()=>{if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;}});
document.querySelectorAll(".chip").forEach(b=>b.addEventListener("click",()=>{$("prompt").value=b.dataset.prompt;$("prompt").focus();}));
$("githubOpen").addEventListener("click",()=>$("github").scrollIntoView({behavior:"smooth",block:"start"}));
function slug(s){return (s||"my-game").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,48)||"my-game";}
function titleFromPrompt(p){const s=p.trim().replace(/[.!?].*$/s,"").split(/\s+/).slice(0,7).join(" ");return s? s[0].toUpperCase()+s.slice(1):"My New Game";}
function detectSystems(p){
 const t=p.toLowerCase(), all=[
 ["Touch controls",/touch|mobile|phone|steer|joystick|button|controller/],
 ["Player movement",/player|character|drive|truck|car|vehicle|movement|walking/],
 ["Camera system",/camera|third.person|first.person|driving|3d/],
 ["World & levels",/world|open.world|map|road|level|terrain|city|environment/],
 ["AI & traffic",/traffic|ai|npc|enemy|pedestrian|opponent/],
 ["Physics",/physics|realistic|collision|damage|suspension|vehicle|truck|car/],
 ["Audio",/sound|audio|engine|music|horn|weather/],
 ["Weather & time",/weather|rain|snow|day.night|time.cycle/],
 ["Inventory & economy",/inventory|money|economy|shop|garage|upgrade|craft|resource/],
 ["Missions & quests",/mission|quest|job|delivery|objective/],
 ["Save/load",/save|load|progress|profile/],
 ["UI & settings",/menu|settings|hud|interface|pause|graphics/],
 ["Multiplayer-ready architecture",/online|multiplayer|co.op|server/],
 ["Mobile optimization",/mobile|android|phone|ios|low.poly|performance/]
 ];
 let found=all.filter(x=>x[1].test(t)).map(x=>x[0]);
 ["Player movement","Camera system","World & levels","UI & settings","Save/load"].forEach(x=>{if(!found.includes(x))found.push(x)});
 return [...new Set(found)];
}
function buildFiles(project){
 const files={};
 files["README.md"]=`# ${project.title}\n\n${project.prompt}\n\n## Target\n- Engine: ${project.engineLabel}\n- Device: ${project.target}\n- Visual style: ${project.style}\n- Scope: ${project.scope}\n\n## Generated systems\n${project.systems.map(s=>"- "+s).join("\n")}\n\n## Build order\n${project.roadmap.map((s,i)=>`${i+1}. ${s}`).join("\n")}\n\n## Important\nThis is a starter scaffold generated from a prompt, not a complete finished game. Open it in the selected engine, replace placeholder assets, test on device, and configure Android export/signing.\n`;
 files["game-blueprint.json"]=JSON.stringify(project,null,2);
 if(project.engine==="godot"||project.engine==="both"){
  files["project.godot"]=`config_version=5\n\n[application]\nconfig/name="${project.title.replace(/"/g,"")}"\nrun/main_scene="res://scenes/Main.tscn"\n\n[display]\nwindow/size/viewport_width=1280\nwindow/size/viewport_height=720\nwindow/stretch/mode="canvas_items"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\nrenderer/rendering_method.mobile="gl_compatibility"\n`;
  files["scenes/Main.tscn"]='[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://scripts/main.gd" id="1"]\n\n[node name="Main" type="Node3D"]\nscript = ExtResource("1")\n\n[node name="WorldEnvironment" type="WorldEnvironment" parent="."]\n\n[node name="DirectionalLight3D" type="DirectionalLight3D" parent="."]\nrotation = Vector3(-0.8, 0.3, 0)\nlight_energy = 1.2\n\n[node name="Ground" type="MeshInstance3D" parent="."]\nposition = Vector3(0, -0.5, 0)\nmesh = PlaneMesh.new()\n';
  files["scripts/main.gd"]=`extends Node3D\n\n## Starter entry point for ${project.title}. Extend this script with game-specific systems.\n@export var world_label: String = \"${project.title.replace(/"/g,"")}\" \n\nfunc _ready() -> void:\n    print(\"Loaded: \", world_label)\n    _create_placeholder_world()\n\nfunc _create_placeholder_world() -> void:\n    # Replace this simple placeholder with your real level, assets, lighting and gameplay.\n    var floor_mesh := BoxMesh.new()\n    floor_mesh.size = Vector3(30.0, 1.0, 30.0)\n    var floor_node := MeshInstance3D.new()\n    floor_node.name = \"PlaceholderFloor\"\n    floor_node.mesh = floor_mesh\n    floor_node.position.y = -1.0\n    add_child(floor_node)\n`;
  files["scripts/mobile_controls.gd"]=`extends CanvasLayer\n\n## UI scaffold: add touch buttons/joystick in a scene and connect them to these actions.\nsignal move_input(direction: Vector2)\nsignal action_pressed(action_name: StringName)\n\nfunc send_move_input(direction: Vector2) -> void:\n    move_input.emit(direction.limit_length(1.0))\n\nfunc send_action(action_name: StringName) -> void:\n    action_pressed.emit(action_name)\n`;
  files[".gitignore"]=".godot/\\n.import/\\nexport.cfg\\nexport_presets.cfg\\n*.tmp\\n";
 }
 if(project.engine==="unity"||project.engine==="both"){
  files["UnityScripts/GameBootstrap.cs"]=`using UnityEngine;\n\n/// <summary>Starter entry point for ${project.title}. Attach to an empty GameObject.</summary>\npublic sealed class GameBootstrap : MonoBehaviour\n{\n    [SerializeField] private string projectTitle = \"${project.title.replace(/"/g,"")}\";\n\n    private void Start()\n    {\n        Debug.Log($\"{projectTitle} starter loaded. Replace placeholders with real gameplay systems.\");\n        EnsureGround();\n    }\n\n    private static void EnsureGround()\n    {\n        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);\n        ground.name = \"Placeholder Ground - replace with level art\";\n        ground.transform.localScale = new Vector3(10f, 1f, 10f);\n    }\n}\n`;
  files["UnityScripts/MobileInputBridge.cs"]=`using UnityEngine;\nusing UnityEngine.Events;\n\n/// <summary>Connect UI Button/joystick events to this mobile input bridge.</summary>\npublic sealed class MobileInputBridge : MonoBehaviour\n{\n    public Vector2 MoveInput { get; private set; }\n    public UnityEvent<string> ActionPressed;\n\n    public void SetMoveInput(Vector2 value) => MoveInput = Vector2.ClampMagnitude(value, 1f);\n    public void PressAction(string actionName) => ActionPressed?.Invoke(actionName);\n    public void ClearMoveInput() => MoveInput = Vector2.zero;\n}\n`;
 }
 files["docs/IMPORT-GUIDE.md"]=`# Import guide\n\n## Godot\n1. Download and unzip this project.\n2. Open Godot 4.x and import the folder containing \`project.godot\`.\n3. Run the main scene. The scene is a placeholder scaffold; add game assets and gameplay logic.\n4. For Android, install/configure Godot export templates and Android SDK/JDK, then create an Android export preset.\n\n## Unity / Unity Mobile Studio\n1. Copy the \`UnityScripts\` folder into your Unity project's \`Assets/Scripts/PromptForge\` folder.\n2. Attach \`GameBootstrap\` to an empty GameObject and add UI controls in the scene.\n3. The JSON blueprint is a planning/export file, not a native Unity project by itself.\n\n## GitHub\nUse the Send to GitHub panel in the app. A GitHub token with repository creation and contents-write permissions is required. The token is held only in page memory while the page remains open; never share it or commit it.\n`;
 return files;
}
function makeProject(){
 const prompt=$("prompt").value.trim();if(!prompt){$("prompt").focus();$("prompt").placeholder="Type a short game idea first…";return null;}
 const engine=$("engine").value, systems=detectSystems(prompt), title=titleFromPrompt(prompt);
 const engineLabel=engine==="both"?"Godot + Unity":engine==="godot"?"Godot 4":"Unity";
 const roadmap=["Create a small playable test scene","Implement core player controls and camera","Add one complete gameplay loop","Connect UI, audio and save/load","Profile on your target phone and optimize","Expand content only after the core loop works"];
 if($("scope").value==="vertical")roadmap.splice(3,0,"Polish one representative level and feedback loop");
 if($("scope").value==="systems")roadmap.splice(0,1,"Define interfaces and data assets for each system");
 return {schemaVersion:1,title,prompt,engine,engineLabel,target:$("target").value,style:$("style").value,scope:$("scope").value,systems,roadmap,generatedAt:new Date().toISOString()};
}
function renderProject(p){
 currentProject=p;const files=buildFiles(p);$("result").hidden=false;$("projectTitle").textContent=p.title;$("summary").textContent=p.prompt;
 $("systemCount").textContent=p.systems.length;$("fileCount").textContent=Object.keys(files).length;$("roadmap").innerHTML="";p.roadmap.forEach(x=>{const li=document.createElement("li");li.textContent=x;$("roadmap").append(li)});
 $("systems").innerHTML="";p.systems.forEach(x=>{const el=document.createElement("span");el.className="systemtag";el.textContent=x;$("systems").append(el)});
 $("filePreview").hidden=true;$("status").textContent="READY";$("result").scrollIntoView({behavior:"smooth",block:"start"});
}
$("generate").addEventListener("click",()=>{const p=makeProject();if(p)renderProject(p)});
function download(name,blob){if(window.PromptForgeNative&&typeof window.PromptForgeNative.saveFile==="function"){const reader=new FileReader();reader.onloadend=()=>{const data=String(reader.result||"").split(",")[1]||"";window.PromptForgeNative.saveFile(name,data,blob.type||"application/octet-stream");};reader.readAsDataURL(blob);return;}const a=document.createElement("a");const url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function exportJSON(){if(!currentProject)return;download(slug(currentProject.title)+"-blueprint.json",new Blob([JSON.stringify(currentProject,null,2)],{type:"application/json"}));}
$("exportJson").addEventListener("click",exportJSON);
function zipStore(files){
 // Minimal ZIP writer using uncompressed entries (store method); UTF-8 filenames.
 const enc=new TextEncoder(), chunks=[], central=[];let offset=0;
 const u16=n=>[n&255,(n>>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
 const crc32=data=>{let c=~0;for(const b of data){c^=b;for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xedb88320:0)}return (~c)>>>0};
 const join=arr=>{let len=arr.reduce((s,a)=>s+a.length,0),out=new Uint8Array(len),pos=0;for(const a of arr){out.set(a,pos);pos+=a.length}return out};
 for(const [name,content] of Object.entries(files)){
  const n=enc.encode(name),d=enc.encode(content),crc=crc32(d),local=join([new Uint8Array([0x50,0x4b,3,4,...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(d.length),...u32(d.length),...u16(n.length),...u16(0)]),n,d]);
  chunks.push(local);central.push(join([new Uint8Array([0x50,0x4b,1,2,...u16(20),...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(crc),...u32(d.length),...u32(d.length),...u16(n.length),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)]),n]));offset+=local.length;
 }
 const cd=join(central),end=new Uint8Array([0x50,0x4b,5,6,...u16(0),...u16(0),...u16(central.length),...u16(central.length),...u32(cd.length),...u32(offset),...u16(0)]);
 return join([...chunks,cd,end]);
}
$("exportZip").addEventListener("click",()=>{if(!currentProject)return;const f=buildFiles(currentProject);download(slug(currentProject.title)+"-starter.zip",new Blob([zipStore(f)],{type:"application/zip"}));});
$("showFiles").addEventListener("click",()=>{
 if(!currentProject)return;const box=$("filePreview");box.innerHTML="";box.className="filebox";
 Object.entries(buildFiles(currentProject)).forEach(([name,content])=>{const d=document.createElement("details");d.className="fileitem";const s=document.createElement("summary");s.textContent=name;const pre=document.createElement("pre");pre.textContent=content;d.append(s,pre);box.append(d)});box.hidden=false;
});
async function ghRequest(url,token,options={}){const r=await fetch(url,{...options,headers:{"Authorization":"Bearer "+token,"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2022-11-28",...(options.headers||{})}});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.message||`GitHub error ${r.status}`);return data;}
$("pushGithub").addEventListener("click",async()=>{
 const token=$("ghToken").value.trim(),repo=slug($("repoName").value);if(!currentProject){$("ghMessage").textContent="Generate a blueprint first.";return;}if(!token){$("ghMessage").textContent="Paste a GitHub token to continue.";return;}
 const btn=$("pushGithub");btn.disabled=true;btn.textContent="Uploading…";$("ghMessage").textContent="Connecting to GitHub…";
 try{
  const user=await ghRequest("https://api.github.com/user",token);
  const r=await ghRequest("https://api.github.com/user/repos",token,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:repo,private:$("visibility").value==="private",auto_init:false,description:"PromptForge game starter: "+currentProject.title})});
  const files=buildFiles(currentProject);let uploaded=0;
  for(const [path,content] of Object.entries(files)){
   const body={message:"Add PromptForge starter file: "+path,content:btoa(unescape(encodeURIComponent(content)))};
   await ghRequest(`https://api.github.com/repos/${encodeURIComponent(user.login)}/${encodeURIComponent(repo)}/contents/${path}`,token,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});uploaded++;
  }
  $("ghMessage").innerHTML="Repository created and "+uploaded+" files uploaded. <a target='_blank' rel='noopener' href='"+r.html_url+"'>Open repository</a>";
 }catch(e){$("ghMessage").textContent="GitHub upload failed: "+e.message+". Check token permissions, repo name, and internet connection.";}
 finally{btn.disabled=false;btn.textContent="Create repository & upload files";$("ghToken").value="";}
});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
